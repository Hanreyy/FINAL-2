import base64
from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify, make_response
from flask_login import login_required, current_user
from restaurant import db, bcrypt
from restaurant.models import User, Table, Item, Order
from werkzeug.utils import secure_filename
import os
import mysql.connector
from flask_bcrypt import Bcrypt


# Changed blueprint name from 'routes' to 'admin_bp' for clarity
admin_bp = Blueprint('admin', __name__, template_folder="admin")
bcrypt = Bcrypt()



db_config = {
    'host': 'localhost',
    'database': 'onlinefood',
    'user': 'root',
    'password': '',
}

def make_header(response):
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, proxy-revalidate'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    return response

def connect_db():

    return mysql.connector.connect(**db_config)

@admin_bp.app_template_filter('b64encode')
def b64encode_filter(data):
    return base64.b64encode(data).decode('utf-8') if data else ''

@admin_bp.route('/')
def index():
    if 'user' not in session:
        return redirect(url_for('admin.login'))

    connection = connect_db()
    cursor = connection.cursor()
    
    cursor.execute("SELECT SUM(total_amount) FROM orders")
    total_sales = cursor.fetchone()[0] or 0 

    cursor.execute("SELECT COUNT(*) FROM customer")
    total_customers = cursor.fetchone()[0]

    cursor.close()
    connection.close()

    response = make_response(render_template(
        'admin_index.html',
        total_sales=total_sales,
        total_customers=total_customers,
    ))
    return response

@admin_bp.route('/login', methods=['GET', 'POST'])
def login():
    # If user is already logged in, redirect to admin index
    if 'user' in session:
        return redirect(url_for('admin.index'))

    if request.method == "POST":
        email = request.form.get("email", "").strip()
        password = request.form.get("password", "").strip()

        if not email or not password:
            flash("Both email and password are required", "danger")
        else:
            try:
                conn = connect_db()
                cursor = conn.cursor(dictionary=True)
                
                # Check if admin exists
                cursor.execute("SELECT * FROM admin WHERE email = %s", (email,))
                admin = cursor.fetchone()

                if admin:
                    # Verify password (in production, use bcrypt.check_password_hash())
                    if password == admin['password']:
                        # Set session variables
                        session['user'] = email
                        session['admin_id'] = admin['id']
                        flash("Login successful!", "success")
                        return redirect(url_for('admin.index'))
                    else:
                        flash("Invalid password", "danger")
                else:
                    flash("Admin account not found", "danger")

            except Exception as e:
                flash(f"Database error: {str(e)}", "danger")
            finally:
                cursor.close()
                conn.close()

    return render_template("admin_login.html")

@admin_bp.route('/logout', methods=['GET', 'POST'])  # Added POST method
def adminlogout():
    session.pop('user', None)
    response = make_response(redirect(url_for('admin.login')))
    response = make_header(response)
    return response

@admin_bp.route('/Manage-Item', methods=['GET', 'POST'])  # Added POST method
def manageitem():
    if 'user' not in session:
        return redirect(url_for('admin.login'))

    try:
        connection = connect_db()
        cursor = connection.cursor()

        # Fetch all categories for dropdown
        cursor.execute("SELECT category_id, category_name FROM category")
        categories = cursor.fetchall()

        if request.method == "POST":
            name = request.form.get('name')
            price = request.form.get('price')
            category_id = request.form.get('category_id')
            image = request.files.get('image')

            if not name or not price or not image or not category_id:
                flash("Missing form data.", "danger")
                return redirect(url_for('admin.manageitem'))

            image_data = image.read()

            try:
                cursor.execute(
                    "INSERT INTO items (item_name, price, image, category_id) VALUES (%s, %s, %s, %s)",
                    (name, price, image_data, category_id)
                )
                connection.commit()
                flash("Item added successfully!", "success")
                return redirect(url_for('admin.manageitem'))
            except Exception as e:
                flash(f"Error inserting item: {str(e)}", "danger")
                return redirect(url_for('admin.manageitem'))

        cursor.execute("""
            SELECT items.item_id, items.item_name, items.price, items.image,items.category_id, category.category_name
            FROM items
            LEFT JOIN category ON items.category_id = category.category_id
        """)
        items = cursor.fetchall()

        processed_items = []
        for item in items:
            item_id, item_name, price, image_data, category_id, category_name = item
            image_base64 = base64.b64encode(image_data).decode('utf-8') if image_data else None
            processed_items.append((item_id, item_name, price, image_base64, category_id, category_name or "Uncategorized"))

        cursor.close()
        connection.close()

    except Exception as e:
        processed_items = []
        categories = []
        flash(f"Error: {str(e)}", "danger")

    return render_template("manage_item.html", items=processed_items, categories=categories)

@admin_bp.route('/delete/<int:item_id>', methods=['GET', 'POST'])  # Added POST method
def delete_item(item_id):
    try:
        connection = connect_db()
        cursor = connection.cursor()
        
        cursor.execute("SELECT item_id FROM items WHERE item_id = %s", (item_id,))
        item = cursor.fetchone()

        if not item:
            flash("Item not found.", "danger")
            return redirect(url_for('admin.manageitem'))

        cursor.execute("DELETE FROM items WHERE item_id = %s", (item_id,))
        connection.commit()
        cursor.close()
        connection.close()
        flash("Item deleted successfully!", "success")
        return redirect(url_for('admin.manageitem'))
    except Exception as e:
        return f"Error deleting item: {str(e)}", 500

@admin_bp.route('/edit-item/<int:item_id>', methods=['GET', 'POST'])  # Correctly has both methods
def edit_item(item_id):
    if request.method == 'POST':
        name = request.form.get('name')
        price = request.form.get('price')
        image = request.files.get('image')

        try:
            connection = connect_db()
            cursor = connection.cursor()

            if image:
                image_data = image.read()
                cursor.execute(
                    "UPDATE items SET item_name=%s, price=%s, image=%s WHERE item_id=%s",
                    (name, price, image_data, item_id),
                )
            else:
                cursor.execute(
                    "UPDATE items SET item_name=%s, price=%s WHERE item_id=%s",
                    (name, price, item_id),
                )

            connection.commit()
            cursor.close()
            connection.close()
            flash("Item updated successfully!", "success")
            return redirect(url_for('admin.manageitem'))
        except Exception as e:
            flash(f"Error updating item: {str(e)}", "danger")
            return redirect(url_for('admin.manageitem'))

    try:
        connection = connect_db()
        cursor = connection.cursor()
        cursor.execute("SELECT item_name, price, image FROM items WHERE item_id = %s", (item_id,))
        item = cursor.fetchone()
        cursor.close()
        connection.close()

        if not item:
            flash("Item not found.", "danger")
            return redirect(url_for('admin.manageitem'))

        item_name, price, image_data = item
        image_base64 = base64.b64encode(image_data).decode('utf-8') if image_data else None
        return render_template("edit_item.html", item_id=item_id, item_name=item_name, price=price, image=image_base64)

    except Exception as e:
        flash(f"Error fetching item data: {str(e)}", "danger")
        return redirect(url_for('admin.manageitem'))

@admin_bp.route('/Manage-User', methods=['GET'])  # Only needs GET
def users():
    if 'user' not in session:
        return redirect(url_for('admin.login'))

    try:
        connection = connect_db()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM customer")
        users = cursor.fetchall()
        cursor.close()
        connection.close()

        return render_template("manage_users.html", users=users)
    except Exception as e:
        flash(f"Error fetching users: {str(e)}", "danger")
        return render_template("manage_users.html", users=[])
    
@admin_bp.route('/delete-user/<int:user_id>', methods=['GET', 'POST'])  # Added POST method
def delete_user(user_id):
    try:
        connection = connect_db()
        cursor = connection.cursor()
        cursor.execute("DELETE FROM customer WHERE customer_id = %s", (user_id,))
        connection.commit()
        cursor.close()
        connection.close()
        flash("User deleted successfully!", "success")
    except Exception as e:
        flash(f"Error deleting user: {str(e)}", "danger")

    return redirect(url_for('admin.users'))

@admin_bp.route('/edit-user/<int:user_id>', methods=['GET', 'POST'])  # Correctly has both methods
def edit_user(user_id):
    connection = connect_db()
    cursor = connection.cursor(dictionary=True)

    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        contact = request.form.get('contact')
        address = request.form.get('address')

        try:
            cursor.execute("""
                UPDATE customer 
                SET name = %s, email = %s, contact = %s, address = %s 
                WHERE customer_id = %s
            """, (name, email, contact, address, user_id))
            connection.commit()
            flash("User updated successfully!", "success")
            return redirect(url_for('admin.users'))
        except Exception as e:
            flash(f"Error updating user: {str(e)}", "danger")

    cursor.execute("SELECT * FROM customer WHERE customer_id = %s", (user_id,))
    user = cursor.fetchone()
    cursor.close()
    connection.close()

    if not user:
        flash("User not found!", "danger")
        return redirect(url_for('admin.users'))

    return render_template("edit_user.html", user=user)

@admin_bp.route('/Manage-Categories', methods=['GET', 'POST'])  # Added POST method
def categories():
    if 'user' not in session:
        return redirect(url_for('admin.login'))

    connection = connect_db()
    cursor = connection.cursor()

    if request.method == 'POST':
        category_name = request.form.get('category_name', '').strip()

        if category_name:
            try:
                cursor.execute("INSERT INTO category (category_name) VALUES (%s)", (category_name,))
                connection.commit()
                flash("Category added successfully!", "success")
            except mysql.connector.Error as err:
                flash(f"Error: {err}", "danger")

    cursor.execute("SELECT category_id, category_name FROM category")
    category_list = cursor.fetchall()

    cursor.close()
    connection.close()

    return render_template("categories.html", categories=category_list)

@admin_bp.route('/Manage-Orders', methods=['GET'])  # Explicitly declare GET method
def manageorders():
    if 'user' not in session:
        return redirect(url_for('admin.login'))

    return render_template("manage_order.html")

@admin_bp.route('/register', methods=['GET', 'POST'])
def register():
    if 'user' in session:  # If already logged in
        return redirect(url_for('admin.index'))

    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        fullname = request.form.get('fullname')

        # Validation
        if not all([email, password, confirm_password]):
            flash('All fields are required', 'danger')
            return redirect(url_for('admin.register'))

        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return redirect(url_for('admin.register'))

        try:
            connection = connect_db()
            cursor = connection.cursor(dictionary=True)
            
            # Check if email exists
            cursor.execute("SELECT * FROM admin WHERE email = %s", (email,))
            if cursor.fetchone():
                flash('Email already registered', 'danger')
                return redirect(url_for('admin.register'))

            # Hash password
            hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
            
            # Insert new admin
            cursor.execute(
                "INSERT INTO admin (email, password, fullname) VALUES (%s, %s, %s)",
                (email, hashed_password, fullname)
            )
            connection.commit()
            
            flash('Registration successful! Please login', 'success')
            return redirect(url_for('admin.login'))

        except mysql.connector.Error as e:
            connection.rollback()
            flash(f'Registration failed: {str(e)}', 'danger')
        finally:
            cursor.close()
            connection.close()

    return render_template('admin_register.html')