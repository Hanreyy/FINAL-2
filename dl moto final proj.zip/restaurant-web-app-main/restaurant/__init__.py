from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_bcrypt import Bcrypt
from flask_migrate import Migrate
from authy.api import AuthyApiClient
from config import Config

# Initialize extensions without app
db = SQLAlchemy()
bcrypt = Bcrypt()
login_manager = LoginManager()
migrate = Migrate()
api = None  # Will be initialized after app creation

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)
    
    # Initialize extensions with app
    db.init_app(app)
    bcrypt.init_app(app)
    login_manager.init_app(app)
    migrate.init_app(app, db)
    
    # Configure login manager
    login_manager.login_view = 'main_routes.login_page'  # Updated to match blueprint name
    login_manager.login_message_category = 'info'
    
    # Initialize Authy API
    global api
    api = AuthyApiClient(app.config['AUTHY_API_KEY'])
    
    # Register blueprints and create database tables
    with app.app_context():
        # Import and register main routes blueprint
        from restaurant.routes import bp as main_routes_bp
        from restaurant.admin import admin_bp as admin_blueprint  # Updated import
    
        app.register_blueprint(main_routes_bp)
        app.register_blueprint(admin_blueprint, url_prefix='/Admin')
        
        db.create_all()
    
    return app

app = create_app()