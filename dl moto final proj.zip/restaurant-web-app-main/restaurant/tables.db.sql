BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "user" (
	"id"	INTEGER NOT NULL,
	"username"	VARCHAR(30) NOT NULL,
	"fullname"	VARCHAR(30) NOT NULL,
	"address"	VARCHAR(50) NOT NULL,
	"phone_number"	INTEGER NOT NULL,
	"password_hash"	VARCHAR(60) NOT NULL,
	UNIQUE("username"),
	PRIMARY KEY("id")
);
CREATE TABLE IF NOT EXISTS "table" (
	"table_id"	INTEGER NOT NULL,
	"table"	INTEGER NOT NULL,
	"time"	VARCHAR(20) NOT NULL,
	"date"	VARCHAR(20) NOT NULL,
	"accomodation"	INTEGER NOT NULL,
	"reservee"	VARCHAR,
	FOREIGN KEY("reservee") REFERENCES "user"("id"),
	PRIMARY KEY("table_id")
);
CREATE TABLE IF NOT EXISTS "item" (
	"item_id"	INTEGER NOT NULL,
	"name"	VARCHAR(30) NOT NULL,
	"description"	VARCHAR(50) NOT NULL,
	"price"	INTEGER NOT NULL,
	"source"	VARCHAR(30) NOT NULL,
	"orderer"	INTEGER,
	FOREIGN KEY("orderer") REFERENCES "user"("id"),
	PRIMARY KEY("item_id")
);
CREATE TABLE IF NOT EXISTS "order" (
	"order_id"	INTEGER NOT NULL,
	"name"	VARCHAR(30),
	"address"	VARCHAR(30) NOT NULL,
	"order_items"	VARCHAR(300) NOT NULL,
	"datetime"	DATETIME DEFAULT (CURRENT_TIMESTAMP),
	FOREIGN KEY("name") REFERENCES "user"("username"),
	PRIMARY KEY("order_id")
);
INSERT INTO "user" VALUES (1,'user1','John Doe','BH2,IIITM Campus',7629839732,'$2b$12$uS6taX1q7g7HB0kHsO/qR.5/GdDFawNTWKz86k8ewzfDjxiL.baUa');
INSERT INTO "user" VALUES (2,'user2','Doe John','BH2,IIITM Campus',9862757703,'$2b$12$fzRLWMh3KJnXU2Rn/U0JMe9VlxG9tr5AosknjJJcQZrdD7OiNkRn2');
INSERT INTO "user" VALUES (3,'user3','Joe Mama','BH2,IIITM Campus',9862757703,'$2b$12$ixeOcWu8C0ZK4rE4a10fxO9NdSsWGAl/eVyvIFoT2hZBbGONjkZjK');
INSERT INTO "user" VALUES (4,'user4','Elvis','BH2,IIITM Campus',7629839732,'$2b$12$mJlXDV2/g6BdOkWeDD7Z2.t0jXjiX7zQsjqi4sd9TE0jm5kVMdvFS');
INSERT INTO "user" VALUES (5,'user5','avo','BH2,IIITM Campus',7629839732,'$2b$12$IByYhgMsW8.oHd1YlQN/1Oa786/f.VrfClyF2Z/6JWh7b5kUrpsEe');
INSERT INTO "user" VALUES (6,'user7','elvis','BH2,IIITM Campus',9884723817,'$2b$12$dQuETRxWbj9qQRm1jHNRsuAuqVJZTdF8qNBInd2XxiGa/y2Vj0huu');
INSERT INTO "user" VALUES (7,'newuser','abcde','BH2,IIITM Campus',7629839732,'$2b$12$zVp4zhSTOeCkO72PERwwje89uz3erDVFyT1iMJnynQ.iWV3XFzDL2');
INSERT INTO "table" VALUES (1,1,'10:00-11:00 am','24/11/21',4,NULL);
INSERT INTO "table" VALUES (2,2,'10:00-11:00 am','24/11/21',4,NULL);
INSERT INTO "table" VALUES (3,6,'11:00-12:00 pm','24/11/21',4,NULL);
INSERT INTO "table" VALUES (4,4,'11:00-12:00 pm','24/11/21',4,NULL);
INSERT INTO "table" VALUES (5,5,'12:00-01:00 pm','24/11/21',4,NULL);
INSERT INTO "table" VALUES (6,5,'01:00-02:00 pm','24/11/21',4,NULL);
INSERT INTO "table" VALUES (7,6,'01:00-02:00 pm','24/11/21',4,NULL);
INSERT INTO "table" VALUES (8,8,'02:00-03:00 pm','24/11/21',4,NULL);
INSERT INTO "table" VALUES (9,1,'03:00-04:00 pm','24/11/21',4,NULL);
INSERT INTO "table" VALUES (10,2,'03:00-04:00 pm','24/11/21',4,NULL);
INSERT INTO "item" VALUES (1,'Barbecue Salad','Delicious Dish',200,'plate1.png',NULL);
INSERT INTO "item" VALUES (2,'Salad with Fish','Delicious Dish',150,'plate2.png',NULL);
INSERT INTO "item" VALUES (3,'Spinach Salad','Delicious Dish',100,'plate3.png',1);
INSERT INTO "item" VALUES (4,'Fresh Salad','Delicious Dish',200,'salad.png',NULL);
INSERT INTO "item" VALUES (5,'Fried Noodles','Delicious Dish',200,'noodles.png',NULL);
INSERT INTO "item" VALUES (6,'Roasted Chicken','Delicious Dish',300,'chicken.png',1);
INSERT INTO "item" VALUES (7,'Cheese Pizza','Delicious Dish',200,'pizza.png',NULL);
INSERT INTO "item" VALUES (8,'Barbecue Salad','Delicious Dish',200,'plate1.png',NULL);
INSERT INTO "item" VALUES (9,'Salad with Fish','Delicious Dish',150,'plate2.png',NULL);
INSERT INTO "order" VALUES (1,'John Doe','BH2,IIITM Campus','Barbecue Salad','2021-11-22 18:09:01');
INSERT INTO "order" VALUES (2,'elvis','BH2,IIITM Campus','Barbecue Salad','2021-11-23 17:09:17');
COMMIT;
