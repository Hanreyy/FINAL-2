import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'your-secret-key-here'
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:@localhost/onlinefood'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    AUTHY_API_KEY = 'your-authy-api-key'