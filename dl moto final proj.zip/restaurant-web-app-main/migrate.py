import sqlite3
import pandas as pd
from sqlalchemy import create_engine, text

# 1. Load SQLite data
sqlite_conn = sqlite3.connect('tables.db.sql')
tables = pd.read_sql("SELECT name FROM sqlite_master WHERE type='table';", sqlite_conn)['name'].tolist()

# 2. Connect to MySQL with explicit database creation
engine = create_engine('mysql+pymysql://root:@localhost/')

with engine.connect() as conn:
    conn.execute(text("CREATE DATABASE IF NOT EXISTS onlinefood;"))
    conn.execute(text("USE onlinefood;"))

# 3. Reconnect to the specific database
engine = create_engine('mysql+pymysql://root:@localhost/onlinefood')

# 4. Transfer tables with progress feedback
for table in tables:
    if table not in ['sqlite_sequence', 'sqlite_stat1']:  # Skip system tables
        print(f"Transferring {table}...")
        try:
            df = pd.read_sql(f"SELECT * FROM {table}", sqlite_conn)
            df.to_sql(
                name=table,
                con=engine,
                if_exists='replace',
                index=False,
                chunksize=500
            )
            # Verify immediately
            with engine.connect() as conn:
                count = conn.execute(text(f"SELECT COUNT(*) FROM {table};")).scalar()
                print(f"✓ {count} rows transferred to {table}")
        except Exception as e:
            print(f"❌ Failed to transfer {table}: {str(e)}")

print("Migration complete. Please refresh phpMyAdmin!")